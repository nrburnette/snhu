#include <iostream>
#include <cctype>
#include <string>
#include "MenuOption1.h"
#include "MenuOption2.h"
#include "RunBackup.h"

int main() {
	//true false variable to keep program running
	bool menuOpen = true;
	//selection for menu
	std::string menuOption;
	//for loop iteration
	int i;


	//run automatic daily backup, stores to ' frequency.dat ' file.
	RunBackup autoRunBackup;
	autoRunBackup.PrintBackup();

	//Menu And Program is open  
	while (menuOpen) {
		std::cout << "Option 1: Product Search" << std::endl;
		std::cout << "Option 2: Item Count" << std::endl;
		std::cout << "Option 3: Item Count as Histogram" << std::endl;
		std::cout << "Option 4: Exit Program" << std::endl;
		
		std::cin >> menuOption;

		//menu input validation
		//first check is for a single digit
		if (menuOption.size() == 1) {
			//second check is for a valid integer
			if (isdigit(menuOption.at(0))) {
				//third series of checks 
				//Option 1 prompt user input
				if (menuOption.at(0) == '1') {                  
					//call MenuOption1 class
					MenuOption1 option1;
					option1.Print();
					
				}
				//Option 2 print frequency of product from file
				else if (menuOption.at(0) == '2') {
					MenuOption2 option2;
					option2.CountProduct2(); //FIXME test
				}
				//Option 3 print frequency of search occurences as histogram
				else if (menuOption.at(0) == '3') {
					MenuOption2 option3;
					option3.CountProduct3();
				}
				//option 4: exit program
				else if (menuOption.at(0) == '4') {
					std::cout << "You Selected Option 4" << std::endl << std::endl;
					std::cout << "Now exiting program.  Have a good day." << std::endl << std::endl;
					menuOpen = false;
				}
				else {
					std::cout << "Choose a valid number" << std::endl << std::endl;
				}
				

			}
			else {
				std::cout << "Input must be a valid number 1 thru 4: " << std::endl;
			}
			
		}
		else {
			std::cout << "Please retry, enter a number 1 thru 4: " << std::endl << std::endl;
        }



	}
}