#pragma once
#ifndef MENUOPTION2_H
#define MENUOPTION2_H




//Menu option 2, and Option 3
class MenuOption2 {
public:
	void CountProduct2();
	void CountProduct3();

private:
	std::string product2;

};




#endif