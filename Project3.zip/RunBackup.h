#pragma once
#ifndef RUNBACKUP_H
#define RUNBACKUP_H




//backup previous day's txt file to .dat file
class RunBackup {
public:
	void PrintBackup() const;

private:
	std::string forRunningBackup;  //used?
};




#endif