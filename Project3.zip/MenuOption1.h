#pragma once
#ifndef MENUOPTION1_H
#define MENUOPTION1_H




//Menu option 1
class MenuOption1{
public:
	void Print() const;
	void SearchProduct(std::string productSearched);

private:
	std::string productSearched;
	int productCounted;
};




#endif