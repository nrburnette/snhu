#include <iostream>
#include <string>
#include <fstream>



#include "MenuOption1.h"
#include "RunBackup.h" //used?

//variable for opening file, variable name is inFS
std::ifstream inFS;
std::string product;
int productCount = 0;
int i;


//this is called by Print(), this takes the user search and returns the count
void MenuOption1::SearchProduct(std::string userSearchItem) {
	//"please Enter a Product Search" present
	//accept user search item
	std::cin >> userSearchItem;
	//assign user input to private variable
	productSearched = userSearchItem;

	//Open file
	inFS.open("CS210_Project_Three_Input_File.txt");

	//confirm file opened succesfully
	if (!inFS.is_open()) {
		std::cout << "Could not open file CS210_Project_Three_Input_File.txt." << std::endl;
		
	}

	//scan and count
	//enter each item in the txt file into 'product' variable one by one
	inFS >> product;
	//make sure the first letter is uppercase
	if (islower(productSearched.at(0))) {
		productSearched.at(0) = toupper(productSearched.at(0));
	}
	//this loop continues until reaching the end of the text file
	while (!inFS.fail()) {
		inFS >> product;


		if (product == productSearched) {  
			productCount++;
		}
	}
	//close file
	inFS.close();

	//return results
	std::cout << productSearched << " " << productCount << std::endl << std::endl;
	productCount = 0;


}

//displays when Option 1 is selected, calls other functions
void MenuOption1::Print() const {
	std::cout << "Please Enter a Product Search: " << std::endl << std::endl;
	MenuOption1 userSearch;
	userSearch.SearchProduct(productSearched);
}

//txt filename
//CS210_Project_Three_Input_File
