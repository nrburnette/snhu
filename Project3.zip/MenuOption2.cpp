#include <iostream>
#include <string>
#include <fstream>
#include <map>
#include <iomanip>

#include "MenuOption2.h"


//variable for opening file, variable name is inFSOption2
std::ifstream inFSOption2;
std::string product2;
std::string checkProduct2;
int productCount2 = 0;  
std::map<std::string, int> option2Map;

//Menu Option 2 
void MenuOption2::CountProduct2() {
	//Count the product and return
	//Open file
	inFSOption2.open("frequency.dat");

	//confirm file opened succesfully
	if (!inFSOption2.is_open()) {
		std::cout << "Could not open file frequency.dat." << std::endl;

	}

	//open file, send to a map
	//this loop continues until reaching the end of the text file
	while (!inFSOption2.fail()) {
		inFSOption2 >> product2;
		option2Map[product2] += 1;
	}

	//display the generated map
	for (const auto& elem : option2Map) {
		std::cout << elem.first << " " << elem.second << '\n';
	}

	std::cout << std::endl;

	//close file
	inFSOption2.close();
	
	//clear map
	option2Map.clear();

}

//Menu Option 3
void MenuOption2::CountProduct3() {
	//Count the product and return
	//Open file
	inFSOption2.open("frequency.dat");

	//confirm file opened succesfully
	if (!inFSOption2.is_open()) {
		std::cout << "Could not open file frequency.dat." << std::endl;

	}

	//open file, send to a map
	//this loop continues until reaching the end of the text file
	while (!inFSOption2.fail()) {
		inFSOption2 >> product2;
		option2Map[product2] += 1;
	}

	//display the generated map
	for (const auto& elem : option2Map) {
		std::cout << elem.first << " " << std::setfill('*') << std::setw(elem.second) << "" << '\n';
	}

	std::cout << std::endl;

	//close file
	inFSOption2.close();

	//clear map
	option2Map.clear();

	//clear setfill
	std::setfill(' ');
}


