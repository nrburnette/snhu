#include <iostream>
#include <string>
#include <fstream>


#include "RunBackup.h"


//make a variable to write the .dat file with
std::ofstream outFS;
std::ifstream inFS2;

std::string tempString;


void RunBackup::PrintBackup() const {
	//backup files here
	inFS2.open("CS210_Project_Three_Input_File.txt");
	outFS.open("frequency.dat");
	//confirm outFS opened frequency.dat
	if (!outFS.is_open()) {
		std::cout << "Error while backing up files.  Files not backed up." << std::endl << std::endl;
	}
	//Write inFS (text file) to outFS (dat file)
	else {
		while (!inFS2.fail()) {
			inFS2 >> tempString;
			outFS << tempString;
			//newline each entry
			outFS << std::endl;
		}
		
	}
	
	
	
	//Close both files
	inFS2.close();
	outFS.close();


	std::cout << "Files succesfully backed up." << std::endl << std::endl; 

}




//txt filename
//CS210_Project_Three_Input_File